//
//  TodoRemainedHucre.swift
//  ToDoApp
//
//  Created by Hasan Alay on 1.10.2023.
//

import UIKit

class TodoHucre: UITableViewCell {

    @IBOutlet weak var arkaplan: UIView!
    @IBOutlet weak var labelTodoContent: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
