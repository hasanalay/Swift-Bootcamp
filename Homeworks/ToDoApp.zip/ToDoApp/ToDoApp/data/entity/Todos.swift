//
//  Todos.swift
//  ToDoApp
//
//  Created by Hasan Alay on 1.10.2023.
//

import Foundation
class Todos {
    var todo_id:Int?
    var todo_name:String?
    
    init(todo_id: Int, todo_name: String) {
        self.todo_id = todo_id
        self.todo_name = todo_name

    }
}
